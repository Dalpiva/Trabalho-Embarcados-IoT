#pragma once
#include "NetworkClientSecure.h"
#define WiFiClientSecure NetworkClientSecure
