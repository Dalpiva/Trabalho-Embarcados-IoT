#########
Libraries
#########

Here is where the Libraries API's descriptions are located:

Supported Peripherals
---------------------

Currently, the Arduino ESP32 supports the following peripherals with Arduino APIs.

+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Peripheral    | ESP32         | ESP32-S2      | ESP32-C3      | ESP32-S3      |     | Comments               |
+===============+===============+===============+===============+===============+=====+========================+
| ADC           | Yes           | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Bluetooth     | Yes           | Not Supported | Not Supported | Not Supported |     | Bluetooth Classic      |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| BLE           | Yes           | Not Supported | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| DAC           | Yes           | Yes           | Not Supported | Not Supported |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Ethernet      | Yes           | Not Supported | Not Supported | Not Supported |     | (*)                    |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| GPIO          | Yes           | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Hall Sensor   | Not Supported | Not Supported | Not Supported | Not Supported |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| I2C           | Yes           | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| I2S           | Yes           | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| LEDC          | Yes           | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Motor PWM     | No            | Not Supported | Not Supported | Not Supported |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Pulse Counter | No            | No            | No            | No            |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| RMT           | Yes           | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| SDIO          | No            | No            | No            | No            |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| SDMMC         | Yes           | Not Supported | Not Supported | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Timer         | Yes           | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Temp. Sensor  | Not Supported | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Touch         | Yes           | Yes           | Not Supported | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| TWAI          | No            | No            | No            | No            |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| UART          | Yes           | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| USB           | Not Supported | Yes           | Yes           | Yes           |     | ESP32-C3 only CDC/JTAG |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+
| Wi-Fi         | Yes           | Yes           | Yes           | Yes           |     |                        |
+---------------+---------------+---------------+---------------+---------------+-----+------------------------+

Notes
^^^^^

(*) SPI Ethernet is supported by all ESP32 families and RMII only for ESP32.

.. note:: Some peripherals are not available for all ESP32 families. To see more details about it, see the corresponding SoC at `Product Selector <https://products.espressif.com>`_ page.

.. include:: common/datasheet.inc

APIs
----

The Arduino ESP32 offers some unique APIs, described in this section:

.. note::
    Please be advised that we cannot ensure continuous compatibility between the Arduino Core ESP32 APIs and ESP8266 APIs, as well as Arduino-Core APIs (Arduino.cc).
    While our aim is to maintain harmony, the addition of new features may result in occasional divergence. We strive to achieve the best possible integration but acknowledge
    that perfect compatibility might not always be feasible. Please refer to the documentation for any specific considerations.

.. toctree::
    :maxdepth: 1
    :glob:

    api/*
